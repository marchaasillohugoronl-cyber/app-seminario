package com.jeisson.proyectomovil;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;  // Importa la clase Toast

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private ImageView chromeIcon;
    private ImageView callIcon;
    private ImageView calculatorIcon;
    private ImageView messageIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        chromeIcon = findViewById(R.id.imageView3);
        callIcon = findViewById(R.id.imageView5);
        calculatorIcon = findViewById(R.id.imageView6);
        messageIcon = findViewById(R.id.imageView7);

        // Intent para abrir Chrome
        chromeIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));
                startActivity(intent);
            }
        });

        // Intent para hacer una llamada
        callIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:123456789"));
                startActivity(intent);
            }
        });

        // Intent para abrir la calculadora usando el nombre del paquete
        calculatorIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                // Nombre del paquete común para la calculadora
                intent.setClassName("com.android.calculator2", "com.android.calculator2.Calculator");
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    // Mostrar un mensaje si no se encuentra la calculadora
                    Toast.makeText(HomeActivity.this, "No se pudo abrir la calculadora", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Intent para enviar un mensaje SMS
        messageIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("sms:123456789"));
                intent.putExtra("sms_body", "Hola, este es un mensaje predefinido.");
                startActivity(intent);
            }
        });
    }
}
